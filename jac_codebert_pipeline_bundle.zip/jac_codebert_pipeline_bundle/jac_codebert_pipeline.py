#!/usr/bin/env python3
"""End-to-end CodeBERT pipeline for Jac vulnerability classification.

This script deliberately trains on *candidate semantic windows* rather than
entire project files. It supports:

1. Caching CodeBERT locally before a hackathon.
2. Building paired vulnerable/fixed windows from the Jac CSV dataset.
3. Canonicalizing simple import aliases, then optionally removing imports.
4. Removing comments and normalizing user-defined identifiers/literals.
5. Training a two-stage system:
      Stage 1: SAFE vs VULNERABLE
      Stage 2: vulnerability type for vulnerable windows
6. Saving metrics, confusion matrices, validation predictions, and artifacts.
7. Scanning an unseen .jac file with sliding windows at inference time.

Important:
- The exact vulnerable lines are used only to construct *training windows*.
- At inference, the same representation is produced by sliding across every
  region of an unknown file. Ground-truth vulnerable lines are never assumed.
- Metadata, explanations, pair IDs, and template IDs are never model features.
"""

from __future__ import annotations

import argparse
import ast
import csv
import difflib
import hashlib
import json
import math
import os
import random
import re
import sys
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any, Iterable, Iterator, Sequence

os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
os.environ.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from datasets import Dataset, DatasetDict
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_recall_fscore_support,
    top_k_accuracy_score,
)
from sklearn.utils.class_weight import compute_class_weight
from transformers import (
    AutoModel,
    AutoModelForSequenceClassification,
    AutoTokenizer,
    DataCollatorWithPadding,
    EarlyStoppingCallback,
    EvalPrediction,
    Trainer,
    TrainingArguments,
    set_seed,
)


# ----------------------------- configuration -----------------------------

DEFAULT_BASE_MODEL = "microsoft/codebert-base"
REQUIRED_COLUMNS = {
    "sample_id",
    "pair_id",
    "template_id",
    "split",
    "label",
    "code_snippet",
    "vulnerable_lines",
}

JAC_KEYWORDS = {
    # Jac-specific
    "node", "edge", "walker", "obj", "has", "can", "with", "entry",
    "root", "here", "visitor", "visit", "revisit", "disengage", "spawn",
    "report", "cl", "sv", "na", "global", "include", "impl", "test",
    "priv", "pub", "async", "await", "by", "llm",
    # Python-like control and declaration words used by Jac
    "def", "class", "enum", "import", "from", "as", "return", "if",
    "elif", "else", "for", "while", "in", "is", "not", "and", "or",
    "match", "case", "try", "except", "finally", "raise", "assert",
    "yield", "lambda", "break", "continue", "pass", "del", "True",
    "False", "None",
}

PRESERVED_TYPES = {
    "str", "int", "float", "bool", "bytes", "list", "dict", "set",
    "tuple", "any", "Any", "type", "JsxElement", "Root", "Exception",
}

# Preserve known security-sensitive APIs and argument names. This is not a
# label lookup: the same deterministic list is applied to every training and
# inference sample.
PRESERVED_SECURITY_IDENTIFIERS = {
    "os", "system", "popen", "subprocess", "run", "Popen", "call",
    "check_output", "shell", "eval", "exec", "compile", "pickle", "load",
    "loads", "sqlite3", "execute", "executemany", "unsafe_html", "requests",
    "request", "get", "post", "put", "delete", "urllib", "urlopen", "open",
    "Path", "pathlib", "resolve", "join", "normpath", "abspath", "secrets",
    "token_hex", "token_urlsafe", "uuid", "uuid1", "uuid4", "random",
    "randint", "choice", "time", "sha256", "md5",
}

SPECIAL_TOKENS = [
    "<JAC>", "<NL>", "<STR>", "<URL>", "<SQL>", "<SHELL>", "<PATH>",
    "<SECRET>", "<HTML>", "<NUM>", "<FUNC>", "<WALKER>", "<NODE>",
    "<EDGE>", "<OBJ>", "<FIELD>", "<ID>", "<IMPORT_REMOVED>",
] + [f"<ID_{index}>" for index in range(64)]


@dataclass(frozen=True)
class PreprocessConfig:
    representation: str = "window"  # window or full
    window_radius: int = 4
    scan_stride: int = 2
    remove_comments: bool = True
    canonicalize_import_aliases: bool = True
    strip_import_lines: bool = True
    normalize_identifiers: bool = True
    normalize_literals: str = "semantic"  # none, basic, semantic
    keep_newlines: bool = True
    prepend_jac_token: bool = True


@dataclass(frozen=True)
class TrainConfig:
    base_model: str = DEFAULT_BASE_MODEL
    max_length: int = 256
    learning_rate: float = 2e-5
    weight_decay: float = 0.01
    epochs: int = 5
    train_batch_size: int = 8
    eval_batch_size: int = 16
    gradient_accumulation_steps: int = 2
    warmup_ratio: float = 0.1
    early_stopping_patience: int = 2
    freeze_encoder: bool = False
    freeze_bottom_layers: int = 0
    seed: int = 42
    local_files_only: bool = False


# ----------------------------- utilities -----------------------------


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    set_seed(seed)


def selected_device() -> str:
    if torch.cuda.is_available():
        return f"cuda:{torch.cuda.get_device_name(0)}"
    if torch.backends.mps.is_available():
        return "mps"
    return "cpu"


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def parse_line_numbers(value: Any) -> list[int]:
    """Parse JSON arrays, Python-like arrays, integers, or simple ranges."""
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return []
    if isinstance(value, list):
        return [int(number) for number in value]
    if isinstance(value, int):
        return [value]

    text = str(value).strip()
    if not text:
        return []

    for parser in (json.loads, ast.literal_eval):
        try:
            parsed = parser(text)
            if isinstance(parsed, int):
                return [parsed]
            if isinstance(parsed, (list, tuple)):
                return sorted({int(number) for number in parsed})
        except (ValueError, SyntaxError, json.JSONDecodeError, TypeError):
            pass

    result: list[int] = []
    for part in re.split(r"[,;\s]+", text):
        if not part:
            continue
        if "-" in part:
            start_text, end_text = part.split("-", 1)
            start, end = int(start_text), int(end_text)
            result.extend(range(min(start, end), max(start, end) + 1))
        else:
            result.append(int(part))
    return sorted(set(result))


def validate_source_dataframe(frame: pd.DataFrame) -> None:
    missing = REQUIRED_COLUMNS - set(frame.columns)
    if missing:
        raise ValueError(f"Dataset is missing columns: {sorted(missing)}")

    if frame.empty:
        raise ValueError("Dataset is empty.")

    allowed_splits = {"train", "validation"}
    observed_splits = set(frame["split"].dropna().astype(str))
    if not observed_splits <= allowed_splits:
        raise ValueError(
            f"Unexpected split values: {sorted(observed_splits - allowed_splits)}"
        )

    for grouping_column in ("pair_id", "template_id"):
        split_counts = frame.groupby(grouping_column)["split"].nunique()
        leaking = split_counts[split_counts > 1]
        if not leaking.empty:
            raise ValueError(
                f"{grouping_column} crosses train/validation: "
                f"{leaking.index[:10].tolist()}"
            )

    for pair_id, group in frame.groupby("pair_id"):
        labels = group["label"].astype(str).tolist()
        if len(group) != 2 or labels.count("SAFE") != 1:
            raise ValueError(
                f"Pair {pair_id!r} must contain one SAFE and one vulnerable row."
            )


# ----------------------------- Jac preprocessing -----------------------------


IMPORT_RE = re.compile(
    r"^\s*import\s+(?P<module>[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*)"
    r"(?:\s+as\s+(?P<alias>[A-Za-z_]\w*))?\s*;?\s*$"
)
FROM_IMPORT_RE = re.compile(
    r"^\s*from\s+(?P<module>[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*)\s+"
    r"import\s+(?P<name>[A-Za-z_]\w*)"
    r"(?:\s+as\s+(?P<alias>[A-Za-z_]\w*))?\s*;?\s*$"
)


def canonicalize_imports(code: str, strip_imports: bool) -> str:
    """Resolve simple aliases before optionally deleting import lines.

    Examples:
        import subprocess as sp;  -> sp.run(...) becomes subprocess.run(...)
        from subprocess import run as r; -> r(...) becomes subprocess.run(...)

    This is intentionally conservative. It does not execute or import anything.
    """
    module_aliases: dict[str, str] = {}
    symbol_aliases: dict[str, str] = {}
    kept_lines: list[str] = []

    for line in code.splitlines():
        import_match = IMPORT_RE.match(line)
        from_match = FROM_IMPORT_RE.match(line)
        if import_match:
            module = import_match.group("module")
            alias = import_match.group("alias") or module.split(".")[0]
            module_aliases[alias] = module
            if not strip_imports:
                kept_lines.append(line)
            continue
        if from_match:
            module = from_match.group("module")
            name = from_match.group("name")
            alias = from_match.group("alias") or name
            symbol_aliases[alias] = f"{module}.{name}"
            if not strip_imports:
                kept_lines.append(line)
            continue
        kept_lines.append(line)

    rewritten = "\n".join(kept_lines)

    # Longest aliases first avoids a short alias partially rewriting a longer one.
    for alias, module in sorted(module_aliases.items(), key=lambda item: -len(item[0])):
        rewritten = re.sub(
            rf"\b{re.escape(alias)}\s*\.",
            f"{module}.",
            rewritten,
        )
    for alias, qualified in sorted(symbol_aliases.items(), key=lambda item: -len(item[0])):
        rewritten = re.sub(
            rf"\b{re.escape(alias)}\b",
            qualified,
            rewritten,
        )

    return rewritten


def strip_comments(code: str) -> str:
    """Remove #, //, and /* */ comments while preserving quoted strings."""
    output: list[str] = []
    index = 0
    length = len(code)
    quote: str | None = None
    triple = False
    escaped = False
    block_comment = False

    while index < length:
        current = code[index]
        following = code[index + 1] if index + 1 < length else ""

        if block_comment:
            if current == "*" and following == "/":
                block_comment = False
                index += 2
            else:
                if current == "\n":
                    output.append("\n")
                index += 1
            continue

        if quote is not None:
            output.append(current)
            if escaped:
                escaped = False
                index += 1
                continue
            if current == "\\":
                escaped = True
                index += 1
                continue
            if triple:
                if code.startswith(quote * 3, index):
                    output.extend([quote, quote])
                    index += 3
                    quote = None
                    triple = False
                else:
                    index += 1
            elif current == quote:
                quote = None
                index += 1
            else:
                index += 1
            continue

        if current in {"'", '"'}:
            if code.startswith(current * 3, index):
                output.extend([current, current, current])
                quote = current
                triple = True
                index += 3
            else:
                output.append(current)
                quote = current
                triple = False
                index += 1
            continue

        if current == "/" and following == "*":
            block_comment = True
            index += 2
            continue

        if current == "/" and following == "/":
            while index < length and code[index] != "\n":
                index += 1
            continue

        if current == "#":
            while index < length and code[index] != "\n":
                index += 1
            continue

        output.append(current)
        index += 1

    return "".join(output)


TOKEN_RE = re.compile(
    r"(?P<TRIPLE_DQ>\"\"\"(?:\\.|(?!\"\"\").)*\"\"\")"
    r"|(?P<TRIPLE_SQ>'''(?:\\.|(?!''').)*''')"
    r"|(?P<DQ>\"(?:\\.|[^\"\\])*\")"
    r"|(?P<SQ>'(?:\\.|[^'\\])*')"
    r"|(?P<IDENT>[A-Za-z_]\w*)"
    r"|(?P<NUMBER>\b(?:0[xX][0-9A-Fa-f]+|\d+(?:\.\d+)?)\b)"
    r"|(?P<WS>\s+)"
    r"|(?P<OTHER>.)",
    flags=re.DOTALL,
)


def unquote_literal(token: str) -> str:
    try:
        parsed = ast.literal_eval(token)
        return parsed if isinstance(parsed, str) else token
    except (ValueError, SyntaxError):
        return token.strip("'\"")


def string_category(token: str, mode: str) -> str:
    if mode == "none":
        return token
    if mode == "basic":
        return "<STR>"

    value = unquote_literal(token)
    lowered = value.lower()

    if re.search(r"https?://|ftp://|file://", value):
        return "<URL>"
    if re.search(r"\b(select|insert|update|delete|drop|union|where|from)\b", lowered):
        return "<SQL>"
    if re.search(r"(?:&&|\|\||;\s*\w|\$\(|`[^`]+`|\b(?:sh|bash|cmd|powershell)\b)", lowered):
        return "<SHELL>"
    if re.search(r"</?[a-z][^>]*>|javascript:", lowered):
        return "<HTML>"
    if "/" in value or "\\" in value or value.startswith((".", "~")):
        return "<PATH>"

    # Conservative secret-like heuristic: long non-space literal with mixed
    # character classes, or a standard token prefix. This is deterministic and
    # runs identically during training and inference.
    classes = sum(
        bool(pattern.search(value))
        for pattern in (
            re.compile(r"[a-z]"),
            re.compile(r"[A-Z]"),
            re.compile(r"\d"),
            re.compile(r"[^A-Za-z0-9\s]"),
        )
    )
    if (
        len(value) >= 16
        and " " not in value
        and classes >= 3
    ) or re.search(r"(?:secret|password|passwd|api[-_]?key|access[-_]?token)", lowered) or re.match(r"^(?:sk-|ghp_|xox[baprs]-|AKIA)[A-Za-z0-9_-]{8,}$", value):
        return "<SECRET>"

    return "<STR>"


def normalize_code(code: str, config: PreprocessConfig) -> str:
    if config.canonicalize_import_aliases:
        code = canonicalize_imports(code, strip_imports=config.strip_import_lines)
    elif config.strip_import_lines:
        code = "\n".join(
            line
            for line in code.splitlines()
            if not IMPORT_RE.match(line) and not FROM_IMPORT_RE.match(line)
        )

    if config.remove_comments:
        code = strip_comments(code)

    identifier_map: dict[str, str] = {}
    next_identifier = 0
    output: list[str] = []
    previous_significant: str | None = None
    declaration_kind: str | None = None

    declaration_markers = {
        "def": "<FUNC>",
        "walker": "<WALKER>",
        "node": "<NODE>",
        "edge": "<EDGE>",
        "obj": "<OBJ>",
        "class": "<OBJ>",
        "has": "<FIELD>",
    }

    for match in TOKEN_RE.finditer(code):
        kind = match.lastgroup
        token = match.group(0)

        if kind in {"TRIPLE_DQ", "TRIPLE_SQ", "DQ", "SQ"}:
            output.append(string_category(token, config.normalize_literals))
            previous_significant = "<STRING>"
            continue

        if kind == "NUMBER":
            output.append(token if config.normalize_literals == "none" else "<NUM>")
            previous_significant = "<NUMBER>"
            continue

        if kind == "WS":
            if config.keep_newlines and "\n" in token:
                output.append("\n")
            else:
                output.append(" ")
            continue

        if kind == "IDENT":
            if token in declaration_markers:
                output.append(token)
                declaration_kind = token
                previous_significant = token
                continue

            preserve = (
                token in JAC_KEYWORDS
                or token in PRESERVED_TYPES
                or token in PRESERVED_SECURITY_IDENTIFIERS
            )

            if declaration_kind is not None and token in {"pub", "priv", "async"}:
                # Jac modifiers may appear between a declaration keyword and its name,
                # for example walker:pub list_items or def:priv helper.
                output.append(token)
            elif declaration_kind is not None:
                replacement = declaration_markers[declaration_kind]
                identifier_map[token] = replacement
                output.append(replacement)
                declaration_kind = None
            elif preserve or not config.normalize_identifiers:
                output.append(token)
            else:
                if token not in identifier_map:
                    replacement = (
                        f"<ID_{next_identifier}>"
                        if next_identifier < 64
                        else "<ID>"
                    )
                    identifier_map[token] = replacement
                    next_identifier += 1
                output.append(identifier_map[token])

            previous_significant = token
            continue

        output.append(token)
        if not token.isspace():
            previous_significant = token

    normalized = "".join(output)
    # Collapse spaces but preserve newlines and structural punctuation.
    normalized = re.sub(r"[ \t]+", " ", normalized)
    normalized = re.sub(r" *\n *", "\n", normalized)
    normalized = re.sub(r"\n{3,}", "\n\n", normalized).strip()

    if config.prepend_jac_token:
        normalized = "<JAC>\n" + normalized
    return normalized


# ----------------------------- window construction -----------------------------


def extract_line_window(
    code: str,
    target_lines: Sequence[int],
    radius: int,
) -> tuple[str, int, int]:
    lines = code.splitlines()
    if not lines:
        return "", 1, 1
    valid = [line for line in target_lines if 1 <= line <= len(lines)]
    if not valid:
        raise ValueError("No valid target lines for window extraction.")
    start = max(1, min(valid) - radius)
    end = min(len(lines), max(valid) + radius)
    return "\n".join(lines[start - 1 : end]), start, end


def align_vulnerable_to_safe_lines(
    vulnerable_code: str,
    safe_code: str,
    vulnerable_lines: Sequence[int],
) -> list[int]:
    """Map vulnerable line numbers to corresponding lines in a fixed sample."""
    vulnerable = vulnerable_code.splitlines()
    safe = safe_code.splitlines()
    matcher = difflib.SequenceMatcher(a=vulnerable, b=safe, autojunk=False)
    mapping: dict[int, int] = {}

    for tag, a_start, a_end, b_start, b_end in matcher.get_opcodes():
        if tag == "equal":
            for offset in range(a_end - a_start):
                mapping[a_start + offset + 1] = b_start + offset + 1
        elif tag == "replace":
            a_len = max(1, a_end - a_start)
            b_len = max(1, b_end - b_start)
            for offset in range(a_end - a_start):
                proportional = min(b_len - 1, int(offset * b_len / a_len))
                mapping[a_start + offset + 1] = b_start + proportional + 1
        elif tag == "delete":
            fallback = min(len(safe), max(1, b_start + 1))
            for old_index in range(a_start + 1, a_end + 1):
                mapping[old_index] = fallback

    result = [mapping.get(line, min(max(line, 1), max(1, len(safe)))) for line in vulnerable_lines]
    return sorted(set(result))


def build_window_dataframe(
    source: pd.DataFrame,
    config: PreprocessConfig,
) -> pd.DataFrame:
    """Create one vulnerable and one matched SAFE candidate window per pair."""
    records: list[dict[str, Any]] = []

    for pair_id, pair in source.groupby("pair_id", sort=False):
        vulnerable = pair[pair["label"] != "SAFE"]
        safe = pair[pair["label"] == "SAFE"]
        if len(vulnerable) != 1 or len(safe) != 1:
            raise ValueError(f"Malformed pair {pair_id!r}.")

        vulnerable_row = vulnerable.iloc[0]
        safe_row = safe.iloc[0]
        target_lines = parse_line_numbers(vulnerable_row["vulnerable_lines"])
        if not target_lines:
            raise ValueError(f"Vulnerable row {vulnerable_row['sample_id']} has no line labels.")

        vulnerable_full = str(vulnerable_row["code_snippet"])
        safe_full = str(safe_row["code_snippet"])
        if config.canonicalize_import_aliases:
            # Keep import lines here so the annotated line numbers do not shift.
            # They are removed later from the extracted window if requested.
            vulnerable_full = canonicalize_imports(vulnerable_full, strip_imports=False)
            safe_full = canonicalize_imports(safe_full, strip_imports=False)
        window_config = replace(config, canonicalize_import_aliases=False)

        if config.representation == "window":
            vulnerable_text, vulnerable_start, vulnerable_end = extract_line_window(
                vulnerable_full,
                target_lines,
                config.window_radius,
            )
            safe_target_lines = align_vulnerable_to_safe_lines(
                vulnerable_full,
                safe_full,
                target_lines,
            )
            safe_text, safe_start, safe_end = extract_line_window(
                safe_full,
                safe_target_lines,
                config.window_radius,
            )
        elif config.representation == "full":
            vulnerable_text = vulnerable_full
            safe_text = safe_full
            vulnerable_start, safe_start = 1, 1
            vulnerable_end = len(vulnerable_text.splitlines())
            safe_end = len(safe_text.splitlines())
        else:
            raise ValueError(f"Unknown representation: {config.representation}")

        shared = {
            "pair_id": str(pair_id),
            "template_id": str(vulnerable_row["template_id"]),
            "split": str(vulnerable_row["split"]),
            "pair_category": str(vulnerable_row.get("pair_category", vulnerable_row["label"])),
        }

        records.append(
            {
                **shared,
                "sample_id": str(vulnerable_row["sample_id"]),
                "label": str(vulnerable_row["label"]),
                "binary_label": "VULNERABLE",
                "input_text": normalize_code(vulnerable_text, window_config),
                "line_start": vulnerable_start,
                "line_end": vulnerable_end,
                "source_hash": sha256_text(str(vulnerable_row["code_snippet"])),
            }
        )
        records.append(
            {
                **shared,
                "sample_id": str(safe_row["sample_id"]),
                "label": "SAFE",
                "binary_label": "SAFE",
                "input_text": normalize_code(safe_text, window_config),
                "line_start": safe_start,
                "line_end": safe_end,
                "source_hash": sha256_text(str(safe_row["code_snippet"])),
            }
        )

    output = pd.DataFrame.from_records(records)
    if output["input_text"].str.len().eq(0).any():
        raise ValueError("Preprocessing produced an empty model input.")
    return output


def save_prepared_data(frame: pd.DataFrame, output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    frame.to_csv(output_dir / "prepared_windows.csv", index=False)
    for split_name in ("train", "validation"):
        frame[frame["split"] == split_name].to_csv(
            output_dir / f"prepared_{split_name}.csv",
            index=False,
        )


# ----------------------------- model training -----------------------------


class ClassWeightedTrainer(Trainer):
    def __init__(self, *args: Any, class_weights: torch.Tensor | None = None, **kwargs: Any):
        super().__init__(*args, **kwargs)
        self.class_weights = class_weights

    def compute_loss(
        self,
        model: torch.nn.Module,
        inputs: dict[str, Any],
        return_outputs: bool = False,
        num_items_in_batch: torch.Tensor | None = None,
        **kwargs: Any,
    ) -> Any:
        labels = inputs.pop("labels")
        outputs = model(**inputs)
        logits = outputs.logits
        weights = self.class_weights.to(logits.device) if self.class_weights is not None else None
        loss = F.cross_entropy(logits, labels, weight=weights)
        return (loss, outputs) if return_outputs else loss


def metrics_function(label_names: Sequence[str]):
    label_ids = list(range(len(label_names)))

    def compute_metrics(prediction: EvalPrediction) -> dict[str, float]:
        logits = prediction.predictions
        if isinstance(logits, tuple):
            logits = logits[0]
        labels = prediction.label_ids
        predictions = np.argmax(logits, axis=-1)
        precision, recall, macro_f1, _ = precision_recall_fscore_support(
            labels,
            predictions,
            average="macro",
            zero_division=0,
        )
        weighted_f1 = f1_score(labels, predictions, average="weighted", zero_division=0)
        result = {
            "accuracy": accuracy_score(labels, predictions),
            "macro_precision": precision,
            "macro_recall": recall,
            "macro_f1": macro_f1,
            "weighted_f1": weighted_f1,
        }
        if len(label_names) > 2:
            probabilities = torch.softmax(torch.tensor(logits), dim=-1).numpy()
            k = min(3, len(label_names))
            result[f"top_{k}_accuracy"] = top_k_accuracy_score(
                labels,
                probabilities,
                k=k,
                labels=label_ids,
            )
        return result

    return compute_metrics


def make_hf_dataset(
    frame: pd.DataFrame,
    target_column: str,
    label2id: dict[str, int],
    tokenizer: Any,
    max_length: int,
) -> DatasetDict:
    splits: dict[str, Dataset] = {}

    for split_name in ("train", "validation"):
        split_frame = frame[frame["split"] == split_name].copy()
        split_frame["labels"] = split_frame[target_column].map(label2id)
        if split_frame["labels"].isna().any():
            bad = split_frame[split_frame["labels"].isna()][target_column].unique().tolist()
            raise ValueError(f"Unknown labels in {split_name}: {bad}")
        split_frame["labels"] = split_frame["labels"].astype(int)

        # Keep only what Trainer needs. The metadata frame is retained separately
        # for predictions and auditing.
        dataset = Dataset.from_pandas(
            split_frame[["input_text", "labels"]],
            preserve_index=False,
        )

        def tokenize_batch(batch: dict[str, list[Any]]) -> dict[str, Any]:
            return tokenizer(
                batch["input_text"],
                truncation=True,
                max_length=max_length,
                padding=False,
            )

        dataset = dataset.map(tokenize_batch, batched=True, desc=f"Tokenizing {split_name}")
        dataset = dataset.remove_columns(["input_text"])
        splits[split_name] = dataset

    return DatasetDict(splits)


def calculate_class_weights(labels: Sequence[int], count: int) -> torch.Tensor:
    classes = np.arange(count)
    weights = compute_class_weight(
        class_weight="balanced",
        classes=classes,
        y=np.asarray(labels),
    )
    return torch.tensor(weights, dtype=torch.float32)


def configure_layer_freezing(
    model: torch.nn.Module,
    freeze_encoder: bool,
    freeze_bottom_layers: int,
) -> None:
    if freeze_encoder:
        for parameter in model.base_model.parameters():
            parameter.requires_grad = False
        return

    if freeze_bottom_layers <= 0:
        return

    base = getattr(model, "roberta", None)
    if base is None:
        base = getattr(model, "base_model", None)
    if base is None or not hasattr(base, "encoder"):
        raise ValueError("Cannot locate CodeBERT encoder layers for selective freezing.")

    if hasattr(base, "embeddings"):
        for parameter in base.embeddings.parameters():
            parameter.requires_grad = False

    layers = base.encoder.layer
    for layer in layers[:freeze_bottom_layers]:
        for parameter in layer.parameters():
            parameter.requires_grad = False


def save_evaluation_artifacts(
    output_dir: Path,
    metadata: pd.DataFrame,
    label_names: Sequence[str],
    predictions: Any,
) -> None:
    logits = predictions.predictions
    if isinstance(logits, tuple):
        logits = logits[0]
    true_ids = predictions.label_ids
    probabilities = torch.softmax(torch.tensor(logits), dim=-1).numpy()
    predicted_ids = probabilities.argmax(axis=1)

    report = classification_report(
        true_ids,
        predicted_ids,
        labels=list(range(len(label_names))),
        target_names=list(label_names),
        output_dict=True,
        zero_division=0,
    )
    matrix = confusion_matrix(
        true_ids,
        predicted_ids,
        labels=list(range(len(label_names))),
    )

    (output_dir / "classification_report.json").write_text(
        json.dumps(report, indent=2),
        encoding="utf-8",
    )
    (output_dir / "confusion_matrix.json").write_text(
        json.dumps(
            {
                "labels": list(label_names),
                "matrix": matrix.tolist(),
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    result = metadata.reset_index(drop=True).copy()
    result["true_label"] = [label_names[index] for index in true_ids]
    result["predicted_label"] = [label_names[index] for index in predicted_ids]
    result["confidence"] = probabilities.max(axis=1)
    result["correct"] = result["true_label"] == result["predicted_label"]
    result["probabilities_json"] = [
        json.dumps(
            {
                label_names[index]: float(row[index])
                for index in range(len(label_names))
            },
            sort_keys=True,
        )
        for row in probabilities
    ]
    result.to_csv(output_dir / "validation_predictions.csv", index=False)


def train_one_stage(
    *,
    stage_name: str,
    frame: pd.DataFrame,
    target_column: str,
    label_names: Sequence[str],
    output_dir: Path,
    preprocess_config: PreprocessConfig,
    train_config: TrainConfig,
) -> dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    label2id = {label: index for index, label in enumerate(label_names)}
    id2label = {index: label for label, index in label2id.items()}

    tokenizer = AutoTokenizer.from_pretrained(
        train_config.base_model,
        local_files_only=train_config.local_files_only,
        trust_remote_code=False,
        use_fast=True,
    )
    added = tokenizer.add_special_tokens(
        {"additional_special_tokens": [
            token for token in SPECIAL_TOKENS
            if token not in tokenizer.get_vocab()
        ]}
    )

    model = AutoModelForSequenceClassification.from_pretrained(
        train_config.base_model,
        num_labels=len(label_names),
        label2id=label2id,
        id2label=id2label,
        local_files_only=train_config.local_files_only,
        trust_remote_code=False,
    )
    if added:
        model.resize_token_embeddings(len(tokenizer))

    configure_layer_freezing(
        model,
        freeze_encoder=train_config.freeze_encoder,
        freeze_bottom_layers=train_config.freeze_bottom_layers,
    )

    datasets = make_hf_dataset(
        frame,
        target_column,
        label2id,
        tokenizer,
        train_config.max_length,
    )

    train_labels = [label2id[label] for label in frame[frame["split"] == "train"][target_column]]
    class_weights = calculate_class_weights(train_labels, len(label_names))

    is_cuda = torch.cuda.is_available()
    arguments = TrainingArguments(
        output_dir=str(output_dir / "checkpoints"),
        overwrite_output_dir=True,
        learning_rate=train_config.learning_rate,
        weight_decay=train_config.weight_decay,
        num_train_epochs=train_config.epochs,
        per_device_train_batch_size=train_config.train_batch_size,
        per_device_eval_batch_size=train_config.eval_batch_size,
        gradient_accumulation_steps=train_config.gradient_accumulation_steps,
        warmup_ratio=train_config.warmup_ratio,
        lr_scheduler_type="linear",
        optim="adamw_torch",
        eval_strategy="epoch",
        save_strategy="epoch",
        logging_strategy="steps",
        logging_steps=20,
        load_best_model_at_end=True,
        metric_for_best_model="macro_f1",
        greater_is_better=True,
        save_total_limit=2,
        report_to=[],
        seed=train_config.seed,
        data_seed=train_config.seed,
        fp16=is_cuda,
        bf16=False,
        dataloader_num_workers=0,
        dataloader_pin_memory=is_cuda,
        remove_unused_columns=True,
        save_safetensors=True,
    )

    trainer = ClassWeightedTrainer(
        model=model,
        args=arguments,
        train_dataset=datasets["train"],
        eval_dataset=datasets["validation"],
        processing_class=tokenizer,
        data_collator=DataCollatorWithPadding(tokenizer=tokenizer),
        compute_metrics=metrics_function(label_names),
        class_weights=class_weights,
        callbacks=[
            EarlyStoppingCallback(
                early_stopping_patience=train_config.early_stopping_patience
            )
        ],
    )

    train_result = trainer.train()
    evaluation = trainer.evaluate()

    final_dir = output_dir / "model"
    trainer.save_model(str(final_dir))
    tokenizer.save_pretrained(str(final_dir))

    validation_metadata = frame[frame["split"] == "validation"].copy()
    predictions = trainer.predict(datasets["validation"])
    save_evaluation_artifacts(
        output_dir,
        validation_metadata,
        label_names,
        predictions,
    )

    manifest = {
        "stage": stage_name,
        "base_model": train_config.base_model,
        "device": selected_device(),
        "labels": list(label_names),
        "label2id": label2id,
        "preprocess": asdict(preprocess_config),
        "training": asdict(train_config),
        "train_rows": int((frame["split"] == "train").sum()),
        "validation_rows": int((frame["split"] == "validation").sum()),
        "class_weights": class_weights.tolist(),
        "train_metrics": train_result.metrics,
        "eval_metrics": evaluation,
    }
    (output_dir / "manifest.json").write_text(
        json.dumps(manifest, indent=2, default=str),
        encoding="utf-8",
    )
    return manifest


def train_pipeline(args: argparse.Namespace) -> None:
    seed_everything(args.seed)
    torch.set_float32_matmul_precision("high")

    preprocess_config = PreprocessConfig(
        representation=args.representation,
        window_radius=args.window_radius,
        scan_stride=args.scan_stride,
        remove_comments=not args.keep_comments,
        canonicalize_import_aliases=not args.no_canonicalize_imports,
        strip_import_lines=not args.keep_imports,
        normalize_identifiers=not args.keep_identifiers,
        normalize_literals=args.normalize_literals,
        keep_newlines=True,
        prepend_jac_token=True,
    )
    train_config = TrainConfig(
        base_model=args.base_model,
        max_length=args.max_length,
        learning_rate=args.learning_rate,
        weight_decay=args.weight_decay,
        epochs=args.epochs,
        train_batch_size=args.train_batch_size,
        eval_batch_size=args.eval_batch_size,
        gradient_accumulation_steps=args.gradient_accumulation_steps,
        warmup_ratio=args.warmup_ratio,
        early_stopping_patience=args.early_stopping_patience,
        freeze_encoder=args.freeze_encoder,
        freeze_bottom_layers=args.freeze_bottom_layers,
        seed=args.seed,
        local_files_only=args.local_files_only,
    )

    source = pd.read_csv(args.dataset)
    validate_source_dataframe(source)
    prepared = build_window_dataframe(source, preprocess_config)

    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    save_prepared_data(prepared, output_dir)
    (output_dir / "preprocess_config.json").write_text(
        json.dumps(asdict(preprocess_config), indent=2),
        encoding="utf-8",
    )

    print(f"Device selected by PyTorch/Trainer: {selected_device()}")
    print(f"Prepared rows: {len(prepared):,}")
    print(prepared.groupby(["split", "binary_label"]).size())

    binary_labels = ["SAFE", "VULNERABLE"]
    binary_manifest = train_one_stage(
        stage_name="binary",
        frame=prepared,
        target_column="binary_label",
        label_names=binary_labels,
        output_dir=output_dir / "binary",
        preprocess_config=preprocess_config,
        train_config=train_config,
    )

    vulnerable = prepared[prepared["label"] != "SAFE"].copy()
    type_labels = sorted(vulnerable["label"].unique().tolist())
    type_manifest = train_one_stage(
        stage_name="type",
        frame=vulnerable,
        target_column="label",
        label_names=type_labels,
        output_dir=output_dir / "type",
        preprocess_config=preprocess_config,
        train_config=train_config,
    )

    summary = {
        "binary": binary_manifest["eval_metrics"],
        "type": type_manifest["eval_metrics"],
    }
    (output_dir / "summary.json").write_text(
        json.dumps(summary, indent=2, default=str),
        encoding="utf-8",
    )
    print(json.dumps(summary, indent=2, default=str))


# ----------------------------- inference scanner -----------------------------


def sliding_windows(code: str, radius: int, stride: int) -> list[dict[str, Any]]:
    lines = code.splitlines()
    if not lines:
        return []
    width = radius * 2 + 1
    windows: list[dict[str, Any]] = []

    if len(lines) <= width:
        return [{"start": 1, "end": len(lines), "text": code}]

    starts = list(range(0, len(lines), max(1, stride)))
    last_start = max(0, len(lines) - width)
    if last_start not in starts:
        starts.append(last_start)

    seen: set[tuple[int, int]] = set()
    for start_zero in sorted(starts):
        end_zero = min(len(lines), start_zero + width)
        start_zero = max(0, end_zero - width)
        key = (start_zero, end_zero)
        if key in seen:
            continue
        seen.add(key)
        windows.append(
            {
                "start": start_zero + 1,
                "end": end_zero,
                "text": "\n".join(lines[start_zero:end_zero]),
            }
        )
    return windows


def load_model_and_tokenizer(model_dir: Path, device: torch.device):
    tokenizer = AutoTokenizer.from_pretrained(model_dir, local_files_only=True)
    model = AutoModelForSequenceClassification.from_pretrained(
        model_dir,
        local_files_only=True,
    )
    model.to(device)
    model.eval()
    return tokenizer, model


def batched_probabilities(
    texts: Sequence[str],
    tokenizer: Any,
    model: torch.nn.Module,
    device: torch.device,
    max_length: int,
    batch_size: int,
) -> np.ndarray:
    chunks: list[np.ndarray] = []
    with torch.inference_mode():
        for start in range(0, len(texts), batch_size):
            batch = texts[start : start + batch_size]
            encoded = tokenizer(
                list(batch),
                return_tensors="pt",
                padding=True,
                truncation=True,
                max_length=max_length,
            )
            encoded = {key: value.to(device) for key, value in encoded.items()}
            logits = model(**encoded).logits
            chunks.append(torch.softmax(logits, dim=-1).cpu().numpy())
    return np.concatenate(chunks, axis=0) if chunks else np.empty((0, 0))


def non_maximum_suppression(
    findings: list[dict[str, Any]],
    maximum: int,
) -> list[dict[str, Any]]:
    selected: list[dict[str, Any]] = []
    for finding in sorted(findings, key=lambda item: item["vulnerability_confidence"], reverse=True):
        overlaps = False
        for existing in selected:
            intersection = max(
                0,
                min(finding["line_end"], existing["line_end"])
                - max(finding["line_start"], existing["line_start"])
                + 1,
            )
            union = (
                finding["line_end"] - finding["line_start"] + 1
                + existing["line_end"] - existing["line_start"] + 1
                - intersection
            )
            if union and intersection / union >= 0.6 and finding["predicted_type"] == existing["predicted_type"]:
                overlaps = True
                break
        if not overlaps:
            selected.append(finding)
        if len(selected) >= maximum:
            break
    return sorted(selected, key=lambda item: item["line_start"])


def scan_file(args: argparse.Namespace) -> None:
    model_root = Path(args.model_dir)
    preprocess_data = json.loads((model_root / "preprocess_config.json").read_text(encoding="utf-8"))
    config = PreprocessConfig(**preprocess_data)

    device = torch.device(
        "cuda" if torch.cuda.is_available()
        else "mps" if torch.backends.mps.is_available()
        else "cpu"
    )

    binary_tokenizer, binary_model = load_model_and_tokenizer(model_root / "binary" / "model", device)
    type_tokenizer, type_model = load_model_and_tokenizer(model_root / "type" / "model", device)

    code = Path(args.file).read_text(encoding="utf-8")
    if config.canonicalize_import_aliases:
        code = canonicalize_imports(code, strip_imports=False)
    window_config = replace(config, canonicalize_import_aliases=False)
    candidates = sliding_windows(code, config.window_radius, config.scan_stride)
    processed = [normalize_code(candidate["text"], window_config) for candidate in candidates]

    binary_probabilities = batched_probabilities(
        processed,
        binary_tokenizer,
        binary_model,
        device,
        args.max_length,
        args.batch_size,
    )
    binary_label2id = binary_model.config.label2id
    vulnerable_id = binary_label2id["VULNERABLE"]

    vulnerable_indices = [
        index
        for index, probability in enumerate(binary_probabilities[:, vulnerable_id])
        if probability >= args.threshold
    ]

    findings: list[dict[str, Any]] = []
    if vulnerable_indices:
        type_probabilities = batched_probabilities(
            [processed[index] for index in vulnerable_indices],
            type_tokenizer,
            type_model,
            device,
            args.max_length,
            args.batch_size,
        )
        for local_index, candidate_index in enumerate(vulnerable_indices):
            type_id = int(type_probabilities[local_index].argmax())
            candidate = candidates[candidate_index]
            findings.append(
                {
                    "line_start": candidate["start"],
                    "line_end": candidate["end"],
                    "binary_confidence": float(binary_probabilities[candidate_index, vulnerable_id]),
                    "predicted_type": type_model.config.id2label[type_id],
                    "vulnerability_confidence": float(type_probabilities[local_index, type_id]),
                    "code": candidate["text"],
                }
            )

    findings = non_maximum_suppression(findings, args.max_findings)
    result = {
        "file": str(Path(args.file)),
        "device": str(device),
        "windows_scanned": len(candidates),
        "threshold": args.threshold,
        "findings": findings,
    }
    rendered = json.dumps(result, indent=2)
    if args.output_json:
        Path(args.output_json).write_text(rendered, encoding="utf-8")
    print(rendered)


# ----------------------------- cache model -----------------------------


def cache_base_model(args: argparse.Namespace) -> None:
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    tokenizer = AutoTokenizer.from_pretrained(
        args.base_model,
        trust_remote_code=False,
        use_fast=True,
    )
    model = AutoModel.from_pretrained(
        args.base_model,
        trust_remote_code=False,
    )
    tokenizer.save_pretrained(output)
    model.save_pretrained(output, safe_serialization=True)
    print(f"Cached {args.base_model} in {output}")


# ----------------------------- command line -----------------------------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Train and run a CodeBERT Jac vulnerability classifier."
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    cache_parser = subparsers.add_parser("cache", help="Download and cache CodeBERT locally.")
    cache_parser.add_argument("--base-model", default=DEFAULT_BASE_MODEL)
    cache_parser.add_argument("--output", default="models/codebert-base")
    cache_parser.set_defaults(function=cache_base_model)

    train_parser = subparsers.add_parser("train", help="Train binary and type classifiers.")
    train_parser.add_argument("--dataset", required=True, type=Path)
    train_parser.add_argument("--output", default="jac_codebert_output", type=Path)
    train_parser.add_argument("--base-model", default=DEFAULT_BASE_MODEL)
    train_parser.add_argument("--local-files-only", action="store_true")
    train_parser.add_argument("--representation", choices=("window", "full"), default="window")
    train_parser.add_argument("--window-radius", type=int, default=4)
    train_parser.add_argument("--scan-stride", type=int, default=2)
    train_parser.add_argument("--keep-comments", action="store_true")
    train_parser.add_argument("--keep-imports", action="store_true")
    train_parser.add_argument("--no-canonicalize-imports", action="store_true")
    train_parser.add_argument("--keep-identifiers", action="store_true")
    train_parser.add_argument(
        "--normalize-literals",
        choices=("none", "basic", "semantic"),
        default="semantic",
    )
    train_parser.add_argument("--max-length", type=int, default=256)
    train_parser.add_argument("--learning-rate", type=float, default=2e-5)
    train_parser.add_argument("--weight-decay", type=float, default=0.01)
    train_parser.add_argument("--epochs", type=int, default=5)
    train_parser.add_argument("--train-batch-size", type=int, default=8)
    train_parser.add_argument("--eval-batch-size", type=int, default=16)
    train_parser.add_argument("--gradient-accumulation-steps", type=int, default=2)
    train_parser.add_argument("--warmup-ratio", type=float, default=0.1)
    train_parser.add_argument("--early-stopping-patience", type=int, default=2)
    train_parser.add_argument("--freeze-encoder", action="store_true")
    train_parser.add_argument("--freeze-bottom-layers", type=int, default=0)
    train_parser.add_argument("--seed", type=int, default=42)
    train_parser.set_defaults(function=train_pipeline)

    scan_parser = subparsers.add_parser("scan", help="Scan an unseen .jac file.")
    scan_parser.add_argument("--model-dir", required=True, type=Path)
    scan_parser.add_argument("--file", required=True, type=Path)
    scan_parser.add_argument("--threshold", type=float, default=0.60)
    scan_parser.add_argument("--max-length", type=int, default=256)
    scan_parser.add_argument("--batch-size", type=int, default=16)
    scan_parser.add_argument("--max-findings", type=int, default=20)
    scan_parser.add_argument("--output-json", type=Path)
    scan_parser.set_defaults(function=scan_file)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    args.function(args)


if __name__ == "__main__":
    main()
