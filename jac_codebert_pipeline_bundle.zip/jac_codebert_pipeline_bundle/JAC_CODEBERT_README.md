# Jac CodeBERT vulnerability pipeline

## Design

The model does not consume full projects or ground-truth explanations. It trains
on paired local code windows. User-defined identifiers, comments, imports, and
literals can be normalized. Jac syntax and security-sensitive APIs remain.

The exact vulnerable-line annotation is used only to center training windows.
For an unseen file, the scanner generates overlapping windows across the entire
file, so it never assumes that vulnerable lines are already known.

## Install

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements-jac-codebert.txt
```

## Cache CodeBERT before the hackathon

```bash
python jac_codebert_pipeline.py cache \
  --output models/codebert-base
```

## Train from the local cache

```bash
python jac_codebert_pipeline.py train \
  --dataset jac_vulnerability_dataset_v2_5000.csv \
  --base-model models/codebert-base \
  --local-files-only \
  --require-cuda \
  --repair-split \
  --output runs/jac-codebert \
  --representation window \
  --window-radius 4 \
  --scan-stride 2 \
  --max-length 256 \
  --epochs 100 \
  --max-train-seconds 3600 \
  --train-batch-size 8 \
  --eval-batch-size 16 \
  --gradient-accumulation-steps 2
```

For a quick classifier-head baseline, add `--freeze-encoder`. For partial
fine-tuning, use `--freeze-bottom-layers 8` instead.

`--repair-split` is required for the bundled synthetic dataset. Identifier and
literal normalization causes many augmented rows to collapse to identical
model inputs. The repair groups pairs, source templates, and identical
normalized inputs before splitting, and writes `prepared_split_audit.json`.
Without this flag, training fails fast if normalized inputs cross the split.

On H100, the pipeline selects BF16 and TF32 automatically. On T4 it falls back
to FP16. `--require-cuda` prevents an expensive job from silently running on
CPU because of a bad allocation or CPU-only PyTorch build. Run a one-epoch
`--freeze-encoder` smoke test before the full job.

`--max-train-seconds 3600` caps optimizer time across both stages and assigns
half of the budget to each. Setup, tokenization, evaluation, and packaging are
outside the cap. Early stopping can finish sooner when validation macro F1 no
longer improves; continuing only to consume the clock would overfit this small
synthetic corpus.

## Scan an unknown Jac file

```bash
python jac_codebert_pipeline.py scan \
  --model-dir runs/jac-codebert \
  --file example.jac \
  --threshold 0.60 \
  --output-json findings.json
```

## Important limitations

- The source corpus is synthetic and template-derived.
- A high validation score on this split does not establish production accuracy.
- The preprocessor is lexical, not a full Jac parser.
- Run `jac check` on corpus samples with the Jac release used at the event.
- Do not use explanations, IDs, vulnerable lines, or pair categories as model features.
