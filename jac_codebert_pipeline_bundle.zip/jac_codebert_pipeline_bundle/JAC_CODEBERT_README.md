# Jac CodeBERT vulnerability pipeline

## Design

The model does not consume full projects or ground-truth explanations. It trains
on paired local code windows. User-defined identifiers, comments, imports, and
literals can be normalized. Jac syntax and security-sensitive APIs remain.

The exact vulnerable-line annotation is used only to center training windows.
For an unseen file, the scanner generates overlapping windows across the entire
file, so it never assumes that vulnerable lines are already known.

## Install

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements-jac-codebert.txt
```

## Cache CodeBERT before the hackathon

```bash
python jac_codebert_pipeline.py cache \
  --output models/codebert-base
```

## Train from the local cache

```bash
python jac_codebert_pipeline.py train \
  --dataset jac_vulnerability_dataset_v2_5000.csv \
  --base-model models/codebert-base \
  --local-files-only \
  --output runs/jac-codebert \
  --representation window \
  --window-radius 4 \
  --scan-stride 2 \
  --max-length 256 \
  --epochs 5 \
  --train-batch-size 8 \
  --eval-batch-size 16 \
  --gradient-accumulation-steps 2
```

For a quick classifier-head baseline, add `--freeze-encoder`. For partial
fine-tuning, use `--freeze-bottom-layers 8` instead.

## Scan an unknown Jac file

```bash
python jac_codebert_pipeline.py scan \
  --model-dir runs/jac-codebert \
  --file example.jac \
  --threshold 0.60 \
  --output-json findings.json
```

## Important limitations

- The source corpus is synthetic and template-derived.
- A high validation score on this split does not establish production accuracy.
- The preprocessor is lexical, not a full Jac parser.
- Run `jac check` on corpus samples with the Jac release used at the event.
- Do not use explanations, IDs, vulnerable lines, or pair categories as model features.
